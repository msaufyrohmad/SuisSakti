import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np
import random  # Add this import statement
import datetime
import threading
import paho.mqtt.client as mqtt
import time

class SmartSensorApp(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        # Configure main window
        tk.Tk.wm_title(self, "SmartHome IoT")

        # Create a color-changing title label with left-to-right wave effect
        self.title_label = ColorChangingLabel(self, text="Welcome to SmartHome IoT", font=("Helvetica", 13, "bold"))
        self.title_label.pack(pady=10)

        # Start the wave animation after a 1-second delay
        self.title_label.start_animation()

        # Create container for frames
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (DataPage, ControlPage, AutoPage, SensorPage, SwitchPage, MainMenuPage):
            frame = F(container, self)
            self.frames[F] = frame
            frame.pack(side="top", fill="both", expand=True)

        # Create a menu
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        # Create a File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)

        # Add Data, Control, and Auto options to the File menu
        file_menu.add_command(label="Data", command=lambda: self.show_frame(DataPage))
        file_menu.add_command(label="Control", command=lambda: self.show_frame(ControlPage))
        file_menu.add_command(label="Auto", command=lambda: self.show_frame(AutoPage))

        # Add a separator in the File menu
        file_menu.add_separator()

        # Add an Exit option to the File menu
        file_menu.add_command(label="Exit", command=self.exit_program)

        # Create a Sensors menu
        sensors_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Sensors", menu=sensors_menu)

         # Add a "Deep Sleep" option under the "File" menu
        file_menu.add_command(label="Deep Sleep", command=lambda: self.show_frame(DeepSleepPage))
        
        # Add Temperature & Humidity sensor option
        sensors_menu.add_command(label="Temperature & Humidity", command=lambda: self.show_frame(SensorPage, "Temperature & Humidity"))

        # Add PIR Sensor option
        sensors_menu.add_command(label="PIR Sensor", command=lambda: self.show_frame(SensorPage, "PIR Sensor"))

        # Create a Switches menu
        switches_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Switches", menu=switches_menu)

        # Add Lamp switch option
        switches_menu.add_command(label="Lamp", command=lambda: self.show_frame(SwitchPage, "Lamp"))


        # Initially, main menu page is displayed
        self.show_frame(MainMenuPage)
        self.current_frame = MainMenuPage
        self.last_displayed_content = None

        # MQTT client setup
        self.client = mqtt.Client()
        self.client.username_pw_set(username="public", password="public!@#")
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.connect("115.187.22.64", 1883, 60)
        self.client.loop_start()

    def show_frame(self, cont, sensor_or_switch=None):
        for frame in self.frames.values():
            frame.pack_forget()  # Hide all frames

        frame = self.frames[cont]
        frame.pack(side="top", fill="both", expand=True)

        if sensor_or_switch:
            frame.update_label(sensor_or_switch)

        if cont != MainMenuPage:
            self.last_displayed_content = cont

        self.current_frame = frame

    def exit_program(self):
        result = messagebox.askokcancel("Exit", "Are you sure you want to exit?")
        if result:
            self.destroy()

    def on_connect(self, client, userdata, flags, rc):
        print("Connected with result code "+str(rc))
        client.subscribe("/public/amir/temperature")
        client.subscribe("/public/amir/humidity")
        client.subscribe("/public/amir/motion")

    def on_message(self, client, userdata, msg):
        print(f"Received message: Topic={msg.topic}, Payload={msg.payload}")
        if msg.topic == "/public/amir/temperature":
            if msg.payload is not None:
                self.frames[DataPage].update_temp(float(msg.payload.decode()))
        elif msg.topic == "/public/amir/humidity":
            if msg.payload is not None:
                self.frames[DataPage].update_humidity(float(msg.payload.decode()))
        elif msg.topic == "/public/amir/motion":
            if msg.payload is not None:
                self.frames[DataPage].update_motion(msg.payload.decode())


class ColorChangingLabel(tk.Label):
    def __init__(self, master=None, **kwargs):
        tk.Label.__init__(self, master, **kwargs)
        self.color_index = 0
        self.delay_before_start = 2000  # 2 seconds delay
        self.after(self.delay_before_start, self.start_animation)

    def color_wave(self):
        r = int(127.5 + 127.5 * np.sin(2.0 * np.pi * (0.5 + self.color_index)))
        g = int(127.5 + 127.5 * np.sin(2.0 * np.pi * (0.0 + self.color_index)))
        b = int(127.5 + 127.5 * np.sin(2.0 * np.pi * (1.0 + self.color_index)))

        self.config(foreground="#%02x%02x%02x" % (r, g, b))
        self.color_index += 0.02
        self.after(50, self.color_wave)

    def start_animation(self):
        self.color_wave()


class DataPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.fig_temp_humidity, self.ax_temp_humidity = plt.subplots()
        self.ax_temp_humidity.set_xlabel("Time")
        self.ax_temp_humidity.set_ylabel("Value")
        self.ax_temp_humidity.set_title("Temperature & Humidity Sensor Reading")
        self.line_temp, = self.ax_temp_humidity.plot([], [], label="Temperature")
        self.line_humidity, = self.ax_temp_humidity.plot([], [], label="Humidity")
        self.ax_temp_humidity.legend()

        self.fig_motion, self.ax_motion = plt.subplots()
        self.ax_motion.set_xlabel("Time")
        self.ax_motion.set_ylabel("Motion Detection")
        self.ax_motion.set_title("PIR Sensor Reading")
        self.line_motion, = self.ax_motion.step([], [], where="post", label="Motion")
        self.ax_motion.legend()

        self.canvas_temp_humidity = FigureCanvasTkAgg(self.fig_temp_humidity, master=self)
        self.canvas_temp_humidity.get_tk_widget().pack(side="top", pady=10)

        self.canvas_motion = FigureCanvasTkAgg(self.fig_motion, master=self)
        self.canvas_motion.get_tk_widget().pack(side="top", pady=10)

        self.time_data = []
        self.temp_data = []
        self.humidity_data = []
        self.motion_data = []

        self.motion_detected = False
        self.motion_timer = None

    def update_temp(self, temp):
        self.time_data.append(len(self.time_data) + 1)
        self.temp_data.append(temp)
        self.line_temp.set_data(self.time_data, self.temp_data)
        self.ax_temp_humidity.relim()
        self.ax_temp_humidity.autoscale_view()
        self.canvas_temp_humidity.draw()

    def update_humidity(self, humidity):
        self.humidity_data.append(humidity)
        self.line_humidity.set_data(self.time_data, self.humidity_data)
        self.ax_temp_humidity.relim()
        self.ax_temp_humidity.autoscale_view()
        self.canvas_temp_humidity.draw()

    def update_motion(self, motion):
        if motion == "Motion detected!":
            # Set motion data to 1
            self.motion_data.append(1)
            # Update the graph with the new data
            self.line_motion.set_data(range(len(self.motion_data)), self.motion_data)
            self.ax_motion.relim()
            self.ax_motion.autoscale_view()
            self.canvas_motion.draw()
        elif motion == "No motion detected.":
            # Set motion data to 0
            self.motion_data.append(0)
            # Update the graph with the new data
            self.line_motion.set_data(range(len(self.motion_data)), self.motion_data)
            self.ax_motion.relim()
            self.ax_motion.autoscale_view()
            self.canvas_motion.draw()

class ControlPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text="Control Page", font=("Helvetica", 16, "bold"), foreground="black")
        label.pack(pady=10)

        # Create Lamp control with a single button for on/off
        lamp_label = tk.Label(self, text="LAMP", font=("Helvetica", 12, "bold"), foreground="black")
        lamp_label.pack(pady=(20, 0))

        self.lamp_state = tk.BooleanVar()
        self.lamp_state.set(False)  # Default state is OFF

        # Create a frame to hold the buttons
        button_frame = tk.Frame(self)
        button_frame.pack(pady=5)

        self.lamp_button_on = tk.Button(button_frame, text="Turn On", command=self.turn_on, width=10, height=2)
        self.lamp_button_on.pack(side="left")

        partition_label = tk.Label(button_frame, text=" | ", font=("Helvetica", 12, "bold"))
        partition_label.pack(side="left")

        self.lamp_button_off = tk.Button(button_frame, text="Turn Off", command=self.turn_off, width=10, height=2)
        self.lamp_button_off.pack(side="left")

        # Create Fan control with radio buttons for levels
        fan_label = tk.Label(self, text="FAN", font=("Helvetica", 12, "bold"), foreground="black")
        fan_label.pack(pady=(20, 0))

        # Declare fan_level_var as an instance variable
        self.fan_level_var = tk.IntVar()
        self.fan_level_var.set(0)  # Default fan level

        set_level_button = tk.Button(self, text="Set Level", command=self.auto_set_fan_level)
        set_level_button.pack(pady=5)

        fan_frame = tk.Frame(self)
        fan_frame.pack(pady=10)

        fan_level0_button = tk.Radiobutton(fan_frame, text="Level 0", variable=self.fan_level_var, value=0)
        fan_level0_button.pack(side="left", padx=10)

        fan_level1_button = tk.Radiobutton(fan_frame, text="Level 1", variable=self.fan_level_var, value=1)
        fan_level1_button.pack(side="left", padx=10)

        fan_level2_button = tk.Radiobutton(fan_frame, text="Level 2", variable=self.fan_level_var, value=2)
        fan_level2_button.pack(side="left", padx=10)

        fan_level3_button = tk.Radiobutton(fan_frame, text="Level 3", variable=self.fan_level_var, value=3)
        fan_level3_button.pack(side="left", padx=10)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(MainMenuPage))
        back_button.pack(pady=20)

    def turn_on(self):
        self.lamp_state.set(True)
        self.update_lamp_button_state()
        print("Lamp turned ON")  # Display message in the terminal

    def turn_off(self):
        self.lamp_state.set(False)
        self.update_lamp_button_state()
        print("Lamp turned OFF")  # Display message in the terminal


    def update_lamp_button_state(self):
        if self.lamp_state.get():
            self.lamp_button_on.config(bg="green")
            self.lamp_button_off.config(bg="white")
        else:
            self.lamp_button_on.config(bg="white")
            self.lamp_button_off.config(bg="red")

    def switch_control(self, switch_type, value):
        # Add your logic to control the switches (e.g., send commands to hardware)
        print(f"{switch_type} set to {value}")

    def update_label(self, sensor_or_switch=None):
        pass

    def auto_set_fan_level(self):
        # Remove the random selection
        # random_level = random.choice([1, 2, 3])
        # self.fan_level_var.set(random_level)
        print(f"Manually set Fan Level to {selfa.fan_level_var.get()}")  # Display the selected level in the terminal
if __name__ == "__main__":
    # Add the SmartSensorApp and other classes as needed
    pass


class AutoPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        label = tk.Label(self, text="Auto Page", font=("Helvetica", 16, "bold"), foreground="black")
        label.pack(pady=10, padx=10)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(MainMenuPage))
        back_button.pack()

        auto_setup_label = tk.Label(self, text="Auto Setup", font=("Helvetica", 12, "bold"), foreground="black")
        auto_setup_label.pack(pady=(20, 0))

        # Search box for temperature detection
        temperature_options = [
            "Select Action",
            "Temperature 30°C: Fan Level 2",
            "Temperature Below 20°C: Switch Off Fan",
            "Temperature 22-27°C: Fan Level 1"
        ]
        self.temperature_search_var = tk.StringVar()
        temperature_combobox = ttk.Combobox(self, textvariable=self.temperature_search_var, values=temperature_options, state="readonly", width=40)
        temperature_combobox.set(temperature_options[0])
        temperature_combobox.pack(pady=5)

        # Search box for motion detection
        motion_options = [
            "Select Action",
            "Motion Detect: Turn On Lamp",
            "Motion Not Detected: Turn Off Lamp",
            "Motion Not Detected: Switch Off Fan",
            "Motion Not Detected: Switch Off All",
            "Motion Detected: Switch On Lamp and Fan Level 1"
        ]
        self.motion_search_var = tk.StringVar()
        motion_combobox = ttk.Combobox(self, textvariable=self.motion_search_var, values=motion_options, state="readonly", width=40)
        motion_combobox.set(motion_options[0])
        motion_combobox.pack(pady=5)

        setup_button = tk.Button(self, text="Set Up Auto Mode", command=self.setup_auto_mode)
        setup_button.pack(pady=10)

        # Output label to display selected options
        self.output_label = tk.Label(self, text="", font=("Helvetica", 8), foreground="black")
        self.output_label.pack(pady=10)

    def setup_auto_mode(self):
        temperature_selected_option = self.temperature_search_var.get()
        motion_selected_option = self.motion_search_var.get()

        # Display the selected options in the output label
        output_text = f"Temperature Scenario: {temperature_selected_option}\nMotion Scenario: {motion_selected_option}"
        self.output_label.config(text=output_text)

        # Add your logic to interpret the selected option and perform specific actions
        if selected_option == "Temperature 30°C: Fan Level 2":
            print("Scenario: Temperature reached 30°C. Turning on Fan Level 2.")
            # Add your logic here

        elif selected_option == "Motion Detect: Turn On Lamp":
            print("Scenario: Motion detected. Turning on Lamp.")
            # Add your logic here

        elif selected_option == "Motion Not Detected: Turn Off Lamp":
            print("Scenario: Motion not detected. Turning off Lamp.")
            # Add your logic here

        elif selected_option == "Motion Not Detected: Switch Off Fan":
            print("Scenario: Motion not detected. Switching off Fan.")
            # Add your logic here

        elif selected_option == "Motion Not Detected: Switch Off All":
            print("Scenario: Motion not detected. Switching off all switches (Lamp and Fan).")
            # Add your logic here

        elif selected_option == "Motion Detected: Switch On Lamp and Fan Level 1":
            print("Scenario: Motion detected. Switching on Lamp's switch and turning Fan Level 1.")
            # Add your logic here

        elif selected_option == "Temperature Below 20°C: Switch Off Fan":
            print("Scenario: Temperature below 20°C. Switching off Fan.")
            # Add your logic here

        elif selected_option == "Temperature 22-27°C: Fan Level 1":
            print("Scenario: Temperature in the range of 22-27°C. Setting Fan Level 1.")
            # Add your logic here

        else:
            print("Invalid option selected.")



class ScrollingLabel(tk.Label):
    def __init__(self, master=None, **kwargs):
        tk.Label.__init__(self, master, **kwargs)
        self.text = kwargs.get("text", "")
        self.after(50, self.update_text)

    def update_text(self):
        self.text = self.text[1:] + self.text[0]
        self.config(text=self.text)
        self.after(50, self.update_text)

if __name__ == "__main__":
    # Assuming you have the MainMenuPage class defined
    pass


class SensorPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.label = tk.Label(self, text="", font=("Helvetica", 16, "bold"), foreground="black")
        self.label.pack(pady=10, padx=10)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(MainMenuPage))
        back_button.pack()

    def update_label(self, sensor):
        self.label.config(text=f"Sensor Page: {sensor}")

class SwitchPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.label = tk.Label(self, text="", font=("Helvetica", 16, "bold"), foreground="black")
        self.label.pack(pady=10, padx=10)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(MainMenuPage))
        back_button.pack()

    def update_label(self, switch):
        self.label.config(text=f"Switch Page: {switch}")


class MainMenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        # Add buttons for Data, Control, and Auto options
        data_button = ColorButton(self, text="Data", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(DataPage))
        data_button.pack(side="top", pady=(20, 0))

        control_button = ColorButton(self, text="Control", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(ControlPage))
        control_button.pack(side="top", pady=20)

        auto_button = ColorButton(self, text="Auto", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(AutoPage))
        auto_button.pack(side="top", pady=20)

        sensors_label = tk.Label(self, text="There are 2 sensors:", font=("Helvetica", 10, "bold"), foreground="black")
        sensors_label.pack(side="top", pady=(30, 0))

        sensor1_label = tk.Label(self, text="(Temperature & Humidity)", font=("Helvetica", 10), foreground="black")
        sensor1_label.pack(side="top", pady=5)

        sensor2_label = tk.Label(self, text="(PIR Sensor)", font=("Helvetica", 10), foreground="black")
        sensor2_label.pack(side="top", pady=5)

        switches_label = tk.Label(self, text="There are 1 switch:", font=("Helvetica", 10, "bold"), foreground="black")
        switches_label.pack(side="top", pady=20)

        switch1_label = tk.Label(self, text="(Lamp)", font=("Helvetica", 10), foreground="black")
        switch1_label.pack(side="top", pady=5)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: self.back_to_menu(controller))
        back_button.pack(side="top", pady=30)

class ColorButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        tk.Button.__init__(self, master, **kwargs)
        self.configure(foreground="white", background="#3498db", activebackground="#2980b9", relief=tk.FLAT, pady=10)

class MainMenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        # Add buttons for Data, Control, and Auto options
        data_button = ColorButton(self, text="Data", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(DataPage))
        data_button.pack(side="top", pady=(20, 0))

        control_button = ColorButton(self, text="Control", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(ControlPage))
        control_button.pack(side="top", pady=20)

        auto_button = ColorButton(self, text="Auto", font=("Helvetica", 12, "bold"), command=lambda: controller.show_frame(AutoPage))
        auto_button.pack(side="top", pady=20)

        sensors_label = tk.Label(self, text="There are 2 sensors:", font=("Helvetica", 10, "bold"), foreground="black")
        sensors_label.pack(side="top", pady=(30, 0))

        sensor1_label = tk.Label(self, text="(Temperature & Humidity)", font=("Helvetica", 10), foreground="black")
        sensor1_label.pack(side="top", pady=5)

        sensor2_label = tk.Label(self, text="(PIR Sensor)", font=("Helvetica", 10), foreground="black")
        sensor2_label.pack(side="top", pady=5)

        switches_label = tk.Label(self, text="There are 2 switches:", font=("Helvetica", 10, "bold"), foreground="black")
        switches_label.pack(side="top", pady=20)

        switch1_label = tk.Label(self, text="(Lamp)", font=("Helvetica", 10), foreground="black")
        switch1_label.pack(side="top", pady=5)

        switch2_label = tk.Label(self, text="(Fan)", font=("Helvetica", 10), foreground="black")
        switch2_label.pack(side="top", pady=5)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: self.back_to_menu(controller))
        back_button.pack(side="top", pady=30)

    def back_to_menu(self, controller):
        # If content was displayed on the last click, undo it
        if controller.last_displayed_content:
            controller.show_frame(controller.last_displayed_content)
        else:
            controller.show_frame(MainMenuPage)



class ColorButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        tk.Button.__init__(self, master, **kwargs)
        self.default_color = self.cget("background")
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)

    def on_enter(self, event):
        self.configure(background="lightblue")

    def on_leave(self, event):
        self.configure(background=self.default_color)

if __name__ == "__main__":
    app = SmartSensorApp()
    app.geometry("800x400")
    app.mainloop()