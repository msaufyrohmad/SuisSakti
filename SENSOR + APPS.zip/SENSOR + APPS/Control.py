import tkinter as tk
import paho.mqtt.client as mqtt

class ControlPage(tk.Frame):
    def __init__(self, parent, controller, mqtt_client):
        tk.Frame.__init__(self, parent)
        self.mqtt_client = mqtt_client

        self.label = tk.Label(self, text="Control Page", font=("Helvetica", 16, "bold"), foreground="black")
        self.label.pack(pady=10)

        # Create Lamp control with a single button for on/off
        self.lamp_label = tk.Label(self, text="LAMP", font=("Helvetica", 12, "bold"), foreground="black")
        self.lamp_label.pack(pady=(20, 0))

        self.lamp_state = tk.BooleanVar()
        self.lamp_state.set(False)  # Default state is OFF

        # Create a frame to hold the buttons
        button_frame = tk.Frame(self)
        button_frame.pack(pady=5)

        self.lamp_button_on = tk.Button(button_frame, text="Turn On", command=self.turn_on, width=10, height=2)
        self.lamp_button_on.pack(side="left")

        partition_label = tk.Label(button_frame, text=" | ", font=("Helvetica", 12, "bold"))
        partition_label.pack(side="left")

        self.lamp_button_off = tk.Button(button_frame, text="Turn Off", command=self.turn_off, width=10, height=2)
        self.lamp_button_off.pack(side="left")

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(MainMenuPage))
        back_button.pack(pady=20)

        # Subscribe to the lamp topic
        self.mqtt_client.subscribe("/public/iqram/lamp")
        self.mqtt_client.message_callback_add("/public/iqram/lamp", self.update_lamp_state)

    def update_lamp_state(self, client, userdata, message):
        payload = message.payload.decode("utf-8")
        if payload == "ON":
            self.lamp_state.set(True)
            self.lamp_button_on.config(bg="green")  # Set button color to green when lamp is ON
            self.lamp_button_off.config(bg="white")
            print("Lamp is ON")
        elif payload == "OFF":
            self.lamp_state.set(False)
            self.lamp_button_on.config(bg="white")
            self.lamp_button_off.config(bg="red")  # Set button color to red when lamp is OFF
            print("Lamp is OFF")

    def turn_on(self):
        self.mqtt_client.publish("/public/iqram/lamp", "ON")

    def turn_off(self):
        self.mqtt_client.publish("/public/iqram/lamp", "OFF")


if __name__ == "__main__":
    # MQTT client setup
    mqtt_client = mqtt.Client()
    mqtt_client.username_pw_set(username="public", password="public!@#")
    mqtt_client.connect("115.187.22.64", 1883)
    mqtt_client.loop_start()

    # Create a tkinter window
    root = tk.Tk()
    root.title("Control Page")
    root.geometry("600x400")

    # Create an instance of ControlPage
    control_page = ControlPage(root, None, mqtt_client)
    control_page.pack(fill="both", expand=True)

    # Run the tkinter main loop
    root.mainloop()
