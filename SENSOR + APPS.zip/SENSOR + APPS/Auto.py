import tkinter as tk
from tkinter import ttk
import paho.mqtt.client as mqtt

class SmartSensorApp(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        # Configure main window
        tk.Tk.wm_title(self, "SmartHome IoT")

        # Create container for frames
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (AutoPage,):  # Adjusted the loop here
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Initially, main menu page is displayed
        self.show_frame(AutoPage)

        # MQTT setup
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.username_pw_set("public", password="public!@#")
        self.client.connect("115.187.22.64", 1883)
        self.client.loop_start()  # Start the MQTT loop

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

    def on_connect(self, client, userdata, flags, rc):
        print("Connected to MQTT broker with result code " + str(rc))
        # Subscribe to a topic to receive messages from the broker
        self.client.subscribe("auto_mode_output")

    def on_message(self, client, userdata, msg):
        print("Received message: " + str(msg.payload.decode()))

class AutoPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.controller = controller  # Save reference to controller

        label = tk.Label(self, text="Auto Page", font=("Helvetica", 16, "bold"), foreground="black")
        label.pack(pady=10, padx=10)

        back_button = tk.Button(self, text="Back to Menu", command=lambda: controller.show_frame(AutoPage))
        back_button.pack()

        auto_setup_label = tk.Label(self, text="Auto Setup", font=("Helvetica", 12, "bold"), foreground="black")
        auto_setup_label.pack(pady=(20, 0))

        # Search box for motion detection
        motion_options = [
            "Select Action",
            "Motion Detect: Turn On Lamp",
            "Motion Not Detected: Turn Off Lamp"
        ]
        self.motion_search_var = tk.StringVar()
        motion_combobox = ttk.Combobox(self, textvariable=self.motion_search_var, values=motion_options, state="readonly", width=40)
        motion_combobox.set(motion_options[0])
        motion_combobox.pack(pady=5)

        setup_button = tk.Button(self, text="Set Up Auto Mode", command=self.setup_auto_mode)
        setup_button.pack(pady=10)

        # Output label to display selected options
        self.output_label = tk.Label(self, text="", font=("Helvetica", 8), foreground="black")
        self.output_label.pack(pady=10)

    def setup_auto_mode(self):
        motion_selected_option = self.motion_search_var.get()

        # Display the selected options in the output label
        output_text = f"Motion Scenario: {motion_selected_option}"
        self.output_label.config(text=output_text)

        # Publish the selected options to the MQTT broker
        message = f"Motion Scenario: {motion_selected_option}"
        self.controller.client.publish("auto_mode_setup", message)

        # Add your logic to interpret the selected option and perform specific actions
        if motion_selected_option == "Motion Detect: Turn On Lamp":
            print("Scenario: Motion detected. Turning on Lamp.")
            # Add your logic here

        elif motion_selected_option == "Motion Not Detected: Turn Off Lamp":
            print("Scenario: Motion not detected. Turning off Lamp.")
            # Add your logic here

        else:
            print("Invalid option selected.")
            # Publish the "Invalid option selected." message to the MQTT broker
            self.controller.client.publish("auto_mode_output", "Invalid option selected.")


# Instantiate the SmartSensorApp class
app = SmartSensorApp()

# Start the Tkinter event loop
app.mainloop()
